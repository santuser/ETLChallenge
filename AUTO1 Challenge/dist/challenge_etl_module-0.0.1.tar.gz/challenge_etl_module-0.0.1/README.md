# ETL Package

This is a package created to process and transform data stored in a txt file.
