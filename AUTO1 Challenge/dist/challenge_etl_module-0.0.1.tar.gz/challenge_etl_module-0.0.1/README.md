# ETL Package

Welcome to the package!

This package's objective is manipulating data inside a txt file.
The module has ben created to be as generic as possible, and it 
is fully extensible. 

-Source code and tests inside .\source code and tests
-Installation files inside .\dist
